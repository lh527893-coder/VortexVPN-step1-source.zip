# Vortex VPN — Step 1

این مرحله فقط اسکلت پروژه اندروید و صفحه پایه را فراهم می‌کند.
اتصال VPN واقعی هنوز پیاده‌سازی نشده است و هیچ وضعیت/سرعت ساختگی نشان داده نمی‌شود.

## Build
با GitHub Actions workflow در مسیر `.github/workflows/build-apk.yml` فایل debug APK ساخته می‌شود.

## مرحله بعد
ادغام هسته sing-box/libbox، پیاده‌سازی Android VpnService و خواندن لینک VLESS.
