package com.vortex.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF080D1A)
private val Panel = Color(0xFF111B2E)
private val Neon = Color(0xFF39B7FF)
private val TextMain = Color(0xFFF3F7FF)
private val Muted = Color(0xFF9AAAC4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VortexHome() }
    }
}

@Composable
private fun VortexHome() {
    var config by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy,
        surface = Panel,
        primary = Neon,
        onBackground = TextMain,
        onSurface = TextMain
    )) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Navy)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(22.dp))
            Text("VORTEX", color = Neon, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Text("VPN", color = TextMain, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
            Text("نسخه پایه • مدیریت کانفیگ خصوصی", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(28.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("موتور اتصال هنوز اضافه نشده", color = Neon, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "در این مرحله رابط و ورودی کانفیگ آماده می‌شود. اتصال واقعی در مرحله بعد با هسته sing-box پیاده‌سازی خواهد شد.",
                        color = Muted, textAlign = TextAlign.Center, fontSize = 13.sp, lineHeight = 20.sp
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("کانفیگ خصوصی مدیر", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(14.dp)).padding(14.dp)
                    ) {
                        if (config.isEmpty()) {
                            Text("لینک VLESS را اینجا وارد کن…", color = Muted, fontSize = 14.sp)
                        }
                        BasicTextField(
                            value = config,
                            onValueChange = { config = it; saved = false },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 14.sp),
                            minLines = 3
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { saved = config.trim().startsWith("vless://") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Navy)
                    ) {
                        Text("بررسی و ذخیره محلی", fontWeight = FontWeight.Bold)
                    }
                    if (saved) {
                        Spacer(Modifier.height(8.dp))
                        Text("لینک از نظر قالب اولیه پذیرفته شد؛ هنوز اتصال برقرار نمی‌شود.", color = Neon, fontSize = 12.sp)
                    } else if (config.isNotBlank() && !config.trim().startsWith("vless://")) {
                        Spacer(Modifier.height(8.dp))
                        Text("فعلاً لینک باید با vless:// شروع شود.", color = Color(0xFFFFC857), fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Text("مرحله ۱ از ۳ • آماده‌سازی پروژه", color = Muted, fontSize = 12.sp)
        }
    }
}
